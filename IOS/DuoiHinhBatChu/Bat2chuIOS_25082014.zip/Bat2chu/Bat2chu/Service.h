//
//  ViewController.h
//  AsyncSocketTCPClient
//
//  Created by BINHDU on 7/27/14.
//  Copyright (c) 2014 BinhDu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AsyncSocket.h"


@interface Service : NSObject
{

	AsyncSocket* mAsyncSocket ;
    
}

-(id) initWithIP :(NSString*) ip Port:(NSInteger) port;
-(BOOL) connect ;
- (NSData*) popMsg;
- (BOOL) isConnected ;
- (void) readWithLeng:  (int32_t) leng tag:(long)tag;
- (void) writeWithData: (NSData*) data tag:(long)tag;

@end
