//
//  StartViewController.h
//  Bat2chu
//
//  Created by BINHDU on 7/31/14.
//  Copyright (c) 2014 BinhDu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StartViewController : UIViewController
{   
    
}
@end
