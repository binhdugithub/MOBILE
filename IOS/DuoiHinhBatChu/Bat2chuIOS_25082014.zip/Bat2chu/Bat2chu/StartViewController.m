//
//  StartViewController.m
//  Bat2chu
//
//  Created by BINHDU on 7/31/14.
//  Copyright (c) 2014 BinhDu. All rights reserved.
//

#import "StartViewController.h"
#include "CoreLogic.h"
#import "M_if.h"

@interface StartViewController ()
{
    NSThread *mHMainThread;
}

@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *mIndicator;
@property (weak, nonatomic) IBOutlet UIButton *mStartButton;

@end

@implementation StartViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
  
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    [mHMainThread cancel];
}


- (void) mainThread
{   
    
    while ([mHMainThread isCancelled] == NO)
    {
        UInt32 uiMsg = [[CoreLogic getSingleton] popUIMsg];
        
        if (uiMsg == -1)
        {
            [NSThread sleepForTimeInterval:0.05];
            continue;
        }
        
        switch (uiMsg)
        {
            case UI_CONNECT_OK:
            {
                [self stopIndicator];
                [[CoreLogic getSingleton] createUser];
                [self startIndicator];
                break;
            }
            case UI_CONNECT_FAIL:
            {
                break;
            }
            case UI_DISCONNECT_OK:
            {
                [self stopIndicator];
                [self showMessageBoxInternetError];
                break;
            }
            case UI_CREATE_USER_OK:
            {
                [self stopIndicator];
                [[CoreLogic getSingleton] nextLevel];
                [self startIndicator];
                break;
            }
            case UI_CREATE_USER_FAIL:
            {
                
                break;
            }
            case UI_NEXT_LEVEL_OK:
            {
                [self stopIndicator];
                [self next2PlayView];
                break;
            }
            case UI_NEXT_LEVEL_FAIL:
            {
                
                break;
            }
            case UI_UPDATE_USERNAME_OK:
            {
                break;
            }
            case UI_UPDATE_USERNAME_FAIL:
            {
                break;
            }
            case UI_UPDATE_FACEBOOK_OK:
            {
                
                break;
            }
            case UI_UPDATE_FACEBOOK_FAIL:
            {
                break;
            }
                
            default:
            {
                [NSThread sleepForTimeInterval:0.05];
                break;
            }
            
        }
    }
}

- (IBAction)clickStart:(id)sender
{
    if([[[CoreLogic getSingleton] getImage] length] > 0)
    {
        [self next2PlayView];
        return;
    }
    
    [self startIndicator];
    if ([[CoreLogic getSingleton] getUserID] == 0)
    {
        [[CoreLogic getSingleton] connectServer];
    }
    
     mHMainThread = [[NSThread alloc] initWithTarget:self selector:@selector(mainThread) object:nil];
    [mHMainThread start];
   
}

- (void) next2PlayView
{
    if([NSThread isMainThread])
    {
        
        [self performSegueWithIdentifier:@"Segue2PlayView" sender:nil];
    }
    else
    {
        dispatch_sync(dispatch_get_main_queue(), ^{
           
            [self performSegueWithIdentifier:@"Segue2PlayView" sender:nil];
        });
    }

   
}

- (void) startIndicator
{
    if([NSThread isMainThread])
    {
        [self.mIndicator startAnimating] ;
        [self.mStartButton setEnabled:NO];
    }
    else
    {
        dispatch_sync(dispatch_get_main_queue(), ^{
            [self.mIndicator startAnimating] ;
            [self.mStartButton setEnabled:NO];
        });
    }
}

- (void) stopIndicator
{
    
    if([NSThread isMainThread])
    {
        [self.mIndicator stopAnimating] ;
        [self.mStartButton setEnabled:NO];
    }
    else
    {
        dispatch_sync(dispatch_get_main_queue(), ^{
            [self.mIndicator stopAnimating];
            [self.mStartButton setEnabled:YES];
        });
    }
    
}

- (void) showMessageBoxInternetError
{
    NSString *title = @"Lỗi mạng!" ;
    NSString *msg = @"Không có kết nối mạng" ;
    NSString *titleCancel = @"OK" ;
    
    if([NSThread isMainThread])
    {
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:msg delegate:nil cancelButtonTitle:titleCancel otherButtonTitles:nil];
        [alert show];
    }
    else
    {
        dispatch_sync(dispatch_get_main_queue(), ^{
            
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:msg delegate:nil cancelButtonTitle:titleCancel otherButtonTitles:nil];
            [alert show];
        });
    }
    
   
}

@end
