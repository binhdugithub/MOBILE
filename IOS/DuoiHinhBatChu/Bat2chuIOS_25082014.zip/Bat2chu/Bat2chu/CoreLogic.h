//
//  CoreLogic.h
//  Bat2chu
//
//  Created by BINHDU on 8/3/14.
//  Copyright (c) 2014 BinhDu. All rights reserved.
//

#import <Foundation/Foundation.h>
#include "Service.h"

@interface CoreLogic : NSObject
{
    volatile BOOL isRunning; 
    int32_t mUserID ;
    NSData   *mImage ;
    NSString *mEnResult;
    NSString *mEnSuggestResult;
    NSString *mVnResult;
    int32_t mLevel ;
    int32_t mRuby ;
    
    
    Service *mService ;
    NSLock *mServiceLock;
    
    
}

+(instancetype) getSingleton;
- (int32_t) getUserID;
- (NSData*) getImage;
- (NSString*) getEnResult;
- (NSString*) getEnSuggestResult;
- (NSString*) getVnResult;
- (int32_t) getLevel;
- (int32_t) getRuby;



- (void) connectServer;
- (void) createUser;
- (void) nextLevel;
- (void) updateFacebook;
- (void) updateUsername;
- (int32_t) popUIMsg;

-(BOOL) serviceConnectedServer;

- (void) saveLevel:(int32_t)level andRuby:(int32_t)ruby;
-(void) saveImage:(NSData*)image andEnResult:(NSString*)enResult andEnSuggestResult:(NSString*)enSuggestResult andVnResult:(NSString*)vnResult;

@end
