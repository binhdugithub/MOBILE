//
//  ViewController.m
//  AsyncSocketTCPClient
//
//  Created by BINHDU on 7/27/14.
//  Copyright (c) 2014 BinhDu. All rights reserved.
//

#import "Service.h"
#import "M_if.h"

#define HOST @"192.168.1.12"
#define PORT 1111


@interface Service ()

@property (strong, nonatomic) NSMutableString *mIPServer ;
@property (strong, nonatomic) NSNumber *mPortServer ;
@property (strong, nonatomic) NSMutableArray *mListMsg ;
@property (strong, nonatomic) NSLock* mListMsgMutex ;

@end

@implementation Service

@synthesize mIPServer, mPortServer, mListMsg, mListMsgMutex;

-(id) init
{
    self = [super init];
    if(self)
    {
        mListMsg = [[NSMutableArray alloc] init];
        mListMsgMutex = [[NSLock alloc] init];
        mIPServer = [[NSMutableString alloc]  initWithString:HOST];
        mPortServer = [[NSNumber alloc] initWithInteger:PORT];
      
    }
    
    return self;
    
}

-(id) initWithIP :(NSString*) ip Port:(NSInteger) port
{
    self = [super init];
    if(self)
    {
        mListMsg = [[NSMutableArray alloc] init];
        mListMsgMutex = [[NSLock alloc] init];
        mIPServer = [[NSMutableString alloc]  initWithString:ip];
        mPortServer = [[NSNumber alloc] initWithInteger:port];
    }
    
    return self;
}

- (BOOL) isConnected
{
    return [mAsyncSocket isConnected];
}

- (BOOL) connect
{   
    if(mAsyncSocket == nil)
    {
        NSLog(@"Recontructor mAsyncSocket") ; 
        mAsyncSocket = [[AsyncSocket alloc] initWithDelegate:self];
    }
    else
    {
        NSLog(@"Socket is in use so close socket an recontructor socket");
        [mAsyncSocket disconnect];
        [mAsyncSocket setDelegate:nil] ;
        mAsyncSocket = [[AsyncSocket alloc] initWithDelegate:self];
        
    }
    
    BOOL res = [mAsyncSocket connectToHost:mIPServer onPort:[mPortServer integerValue] withTimeout:-1 error:nil];
    
    return res;
};

- (void) pushMsg : (NSData*) msg
{
    [mListMsgMutex lock];
    [mListMsg addObject:msg];
    [mListMsgMutex unlock];
    
}

- (NSData*) popMsg
{
    NSData* msg = nil ;
    
    [mListMsgMutex lock] ;
    
    if ([mListMsg count] > 0)
    {
        msg = [mListMsg objectAtIndex:0] ;
        [mListMsg removeObjectAtIndex:0];
    }
    
    [mListMsgMutex unlock] ;
    
    return msg;
}

- (void)readWithLeng: (int32_t) leng tag:(long)tag
{
    
    if([mAsyncSocket isConnected])
    {
        [mAsyncSocket readDataToLength:leng withTimeout:-1 tag:tag];
    }
    else
    {
        NSLog(@"Not yet connected to Server");
    }
    
    
}

- (void) readAllDataOnSocket: (long) tag
{
    [mAsyncSocket readDataWithTimeout:-1 tag:tag];
}



- (void) writeWithData: (NSData*) data tag:(long)tag
{
    if([mAsyncSocket isConnected])
    {
        if([NSThread isMainThread])
        {
            [mAsyncSocket writeData:data withTimeout:-1 tag:tag];
        }
        else
        {
            dispatch_sync(dispatch_get_main_queue(), ^{
                [mAsyncSocket writeData:data withTimeout:-1 tag:tag];
            });
        }
        
        
    }
    else
    {
        NSLog(@"Not yet connected to Server");
    }
}



//
//----------------------------implement method of AsyncSocket------------------------------------
//
- (BOOL)onSocketWillConnect:(AsyncSocket *)sock
{
    //NSLog(@"will connet to %@ on port : %@", mIPServer, mPortServer);
	return TRUE;
}

- (void)onSocket:(AsyncSocket *)sock didConnectToHost:(NSString *)host port:(UInt16)port
{
	NSLog(@"Connected To %@:%i.", host, port);
    int32_t MsgType = MSG_RES;
    int32_t MsgResType = MSG_RES_CONNECT_OK;
    MsgType = htonl(MsgType);
    MsgResType = htonl(MsgResType);
    
    NSMutableData *data1 = [NSData dataWithBytesNoCopy:&MsgType length:sizeof(MsgType) freeWhenDone:NO];
    NSMutableData *data2 = [NSData dataWithBytesNoCopy:&MsgResType length:sizeof(MsgResType) freeWhenDone:NO];
    
    NSMutableData *data = [[NSMutableData alloc] init];
    [data appendData:data1];
    [data appendData:data2];
    [self pushMsg:data];
    
  	
}

- (void)onSocket:(AsyncSocket *)sock didReadData:(NSData *)data withTag:(long)tag
{
   
    switch (tag)
    {
        case TAG_LENG_MSG:
        {
            int32_t lengMsg = -1;
            [data getBytes:&lengMsg length:sizeof(lengMsg)];
            lengMsg = ntohl(lengMsg);
            NSLog(@"Will receive msg with leng: %i", lengMsg );
            
            if (lengMsg > 0 )
            {
                [self readWithLeng:lengMsg tag:TAG_MSG];
            }
            
            break;
        }
        case TAG_MSG:
        {
            //store message
            NSLog(@"Received msg with leng: %li", [data length] );
            [mListMsg addObject:data];           
            break;
        }
        default:
        {
            NSLog(@"Don't know this tag message !!");
            break;
        }
    }
    
}

- (void)onSocket:(AsyncSocket *)sock didReadPartialDataOfLength:(CFIndex)partialLength tag:(long)tag
{
	//NSLog(@"Read a part message :%li with tag:%li", partialLength, tag);

}


- (void)onSocket:(AsyncSocket *)sock didWriteDataWithTag:(long)tag
{
	
    switch (tag)
    {
        case TAG_MSG_REQ_CONNECT:
        {
            NSLog(@"Send message with tag :TAG_MSG_REQ_CONNECT");
            [self readWithLeng:sizeof(int32_t) tag:TAG_LENG_MSG];
            break;
        }
        case TAG_MSG_REQ_CREATE_USER:
        {
            NSLog(@"Send message with tag :TAG_MSG_REQ_CREATE_USER");
            [self readWithLeng:sizeof(int32_t) tag:TAG_LENG_MSG];
            break;
        }
        case TAG_MSG_REQ_NEXT_LEVEL:
        {
            NSLog(@"Send message with tag :TAG_MSG_REQ_NEXT_LEVEL");
            [self readWithLeng:sizeof(int32_t) tag:TAG_LENG_MSG];
            break;
        }
        case TAG_MSG_REQ_UPDATE_FACEBOOK:
        {
            NSLog(@"Send message with tag :TAG_MSG_REQ_UPDATE_FACEBOOK");
           [self readWithLeng:sizeof(int32_t) tag:TAG_LENG_MSG];
            break;
        }
        
        case TAG_MSG_REQ_UPDATE_USERNAME:
        {
            NSLog(@"Send message with tag :TAG_MSG_REQ_UPDATE_USERNAME");
            [self readWithLeng:sizeof(int32_t) tag:TAG_LENG_MSG];
            break;
        }
            
        default:
            break;
    }
}


- (void)onSocket:(AsyncSocket *)sock willDisconnectWithError:(NSError *)err
{
	NSLog(@"will disconnect: %@", [err localizedDescription]);
}

- (void)onSocketDidDisconnect:(AsyncSocket *)sock
{
	NSLog(@"disconnected to server ");
	
    [mAsyncSocket setDelegate:nil] ;
    mAsyncSocket = nil ;
    
    int32_t MsgType = MSG_RES;
    int32_t MsgResType = MSG_RES_DISCONNECT_OK;
    MsgType = htonl(MsgType);
    MsgResType = htonl(MsgResType);
    
    NSMutableData *data1 = [NSData dataWithBytesNoCopy:&MsgType length:sizeof(MsgType) freeWhenDone:NO];
    NSMutableData *data2 = [NSData dataWithBytesNoCopy:&MsgResType length:sizeof(MsgResType) freeWhenDone:NO];
    
    NSMutableData *data = [[NSMutableData alloc] init];
    [data appendData:data1];
    [data appendData:data2];
    
    [self pushMsg:data];
    
}

@end
