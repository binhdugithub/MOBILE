//
//  PlayViewController.m
//  Bat2chu
//
//  Created by BINHDU on 7/31/14.
//  Copyright (c) 2014 BinhDu. All rights reserved.
//


#import "PlayViewController.h"
#import "CoreLogic.h"
#import "M_if.h"

@interface PlayViewController ()

@property (weak, nonatomic) IBOutlet UIImageView *mImage;
@property (strong, nonatomic) NSMutableArray *mRandomButton ;
@property (strong, nonatomic) NSMutableArray *mResultButton ;

- (void) checkResult ;

@end

@implementation PlayViewController

@synthesize mImage;
@synthesize mRandomButton;
@synthesize mResultButton;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //view iamge
    UIImage *image = [UIImage imageWithData:[[CoreLogic getSingleton] getImage]];
    [mImage setImage:image];
    //init random button : default 14 button
    mRandomButton = [[NSMutableArray alloc] init] ;
    
    for(int i = 0 ; i < NUM_RANDOM_BUTTON ; i++)
    {
        UIButton *rdButton=[[UIButton alloc]init ];
        CGRect frameButton;
        if(i < 7)
        {
           frameButton = CGRectMake(20 + (i%(NUM_RANDOM_BUTTON/2))*40, 430, 30, 30);
        }
        else{
            
            frameButton = CGRectMake(20 + (i%(NUM_RANDOM_BUTTON/2))*40, 470, 30, 30);
        }
       
        rdButton.frame = frameButton ;
        
       // mRanddomText[2];
        
        NSString *title = [NSString stringWithFormat:@"%c", [[[CoreLogic getSingleton] getEnSuggestResult] characterAtIndex:i]] ;
        
        [rdButton setTitle:title forState:UIControlStateNormal];
        [rdButton setBackgroundColor:[UIColor grayColor]];
        [rdButton addTarget:self action:@selector(clickRandomButton:)forControlEvents:UIControlEventTouchUpInside];
        
        rdButton.tag=i;
        
        [mRandomButton addObject:rdButton] ;
        [self.view addSubview:rdButton] ;
    }
    
    //init result button
    mResultButton = [[NSMutableArray alloc] init] ;
    for(int i= 0 ; i < [[[CoreLogic getSingleton] getEnResult] length] ; i++)
    {
        UIButton *resButton = [[UIButton alloc] init] ;
        CGRect frameButton;
        
        if(i < 7)
        {
            frameButton = CGRectMake(20 + (i%(NUM_RANDOM_BUTTON/2))*40, 350, 30, 30);
        }
        else{
            
            frameButton = CGRectMake(20 + (i%(NUM_RANDOM_BUTTON/2))*40, 490, 30, 30);
        }
        
        resButton.frame = frameButton ;
        
        [resButton setTitle:@"" forState:UIControlStateNormal];
        [resButton setBackgroundColor:[UIColor grayColor]];
        [resButton addTarget:self action:@selector(clickResultButton:)forControlEvents:UIControlEventTouchUpInside];
        
        resButton.tag=-1;
        
        [mResultButton addObject:resButton] ;
        [self.view addSubview:resButton] ;
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}

- (void)clickRandomButton: (UIButton*) sender
{
    for (UIButton *button in mResultButton)
    {
        if (button.tag == -1)
        {
            [button setTitle:[sender titleForState:UIControlStateNormal] forState:UIControlStateNormal] ;
            [button setTag:sender.tag] ;
            [sender setHidden:TRUE] ;
            break;
        }
    }
    
    if([self isFillAll] == TRUE)
    {
        [self checkResult] ;
    }
}

- (void) clickResultButton: (UIButton*) sender
{
    for(UIButton *button in mRandomButton)
    {
        if(button.tag == sender.tag)
        {
            [sender setTitle:@"" forState:UIControlStateNormal];
            [sender setTag: -1] ;
            [button setHidden:FALSE] ;
        }
    }
    
}

- (BOOL) isFillAll
{
    BOOL isFillAll = TRUE ;
    
    for (UIButton *button in mResultButton)
    {
        if (button.tag == -1)
        {
            isFillAll = FALSE ;
            //return isFillAll;
        }
    }
    
    return isFillAll ;
    
}

- (void) checkResult
{
    NSMutableString *myFillResult = [[NSMutableString alloc] initWithString:@""];
    
    for (UIButton *button in mResultButton)
    {
        [myFillResult appendString:[button titleForState:UIControlStateNormal]] ;
        
    }
    
    if([myFillResult compare:[[CoreLogic getSingleton]getEnResult]] == 0)
    {
        [[CoreLogic getSingleton] saveLevel:([[CoreLogic getSingleton] getLevel] + 1)
                                    andRuby:[[CoreLogic getSingleton] getRuby] + RUBY_FOR_NEXT_LEVEL ];
        
        [self performSegueWithIdentifier:@"Segue2ResultView" sender:nil] ; 
    }
    
}


@end
