//
//  CoreLogic.m
//  Bat2chu
//
//  Created by BINHDU on 8/3/14.
//  Copyright (c) 2014 BinhDu. All rights reserved.
//

#import "CoreLogic.h"
#import "M_if.h"

@interface CoreLogic()

@property (strong, nonatomic) NSMutableArray *mListUIMsg ;
@property (strong, nonatomic) NSLock *mListUIMsgLock;

@end

@implementation CoreLogic
@synthesize mListUIMsg, mListUIMsgLock;

+(instancetype) getSingleton
{
    static CoreLogic *shareCore = nil ;
    
    static dispatch_once_t onceToken;
    
    dispatch_once(&onceToken, ^{
        shareCore = [[CoreLogic alloc] init] ;
    });
    
    return shareCore ;
}


-(id)init
{
    
    self = [super init];
    if(self)
    {
        mListUIMsg = [[NSMutableArray alloc] init];
        mListUIMsgLock = [[NSLock alloc] init];
        
        [self loadConfig];
        [self loadData] ;
        [self mainThread];
        
    }
    
    return self;
}

- (int32_t) getUserID
{
    return mUserID;
};

- (NSData*) getImage
{
    return mImage;
};

- (NSString*) getEnResult
{
    return mEnResult;
};

- (NSString*) getEnSuggestResult
{
    return mEnSuggestResult;
};

- (NSString*) getVnResult
{
    return mVnResult;
};

- (int32_t) getLevel
{
    return mLevel;
};

- (int32_t) getRuby
{
    return mRuby;
};


//load config saved in Config.plist
-(void) loadConfig
{
    //init service
    NSString *pathConfig = [[NSBundle mainBundle]
                            pathForResource: @"Config"
                            ofType:@"plist"] ;
    
    NSDictionary *dicConfig = [NSDictionary dictionaryWithContentsOfFile:pathConfig] ;
    
    if (dicConfig != nil)
    {
        
        NSString *lIP = dicConfig[@"ip"];
        NSInteger lPort = [dicConfig[@"port" ] intValue] ;
        mService = [[Service alloc] initWithIP:lIP Port:lPort] ;
        
        NSLog(@"Load config ip : %@  port: %li", lIP, lPort );
    }
    else
    {
        mService = [[Service alloc] init] ;
        NSLog(@"Load config service fail !!");
    }

}


//load data saved in Data.plist
- (void) loadData
{
    //init User
    NSString *pathData = [[NSBundle mainBundle]
                          pathForResource: @"Data"
                          ofType:@"plist"] ;
    
    NSDictionary *dicData = [NSDictionary dictionaryWithContentsOfFile:pathData] ;
    
    if (dicData != nil)
    {
        
        mUserID = [dicData[@"idUser"] intValue];
        mImage = dicData[@"image"];
        mVnResult = dicData[@"vnResult"];
        mEnResult = dicData[@"enResult"];
        mEnSuggestResult = dicData[@"enSuggestResult"];
        mLevel = [dicData[@"level"] intValue] ;
        mRuby = [dicData[@"ruby"] intValue];
        
        NSLog(@"Load User info idUser : %i  level: %i  ruby: %i", mUserID,mLevel,mRuby);
        
    }
    else
    {
        NSLog(@"Load User info fail !!");
    }

}

- (void) saveIdUser : (int32_t) idUsr
{
    NSString *pathData = [[NSBundle mainBundle]
                          pathForResource: @"Data"
                          ofType:@"plist"] ;
    NSMutableDictionary *dicData = [NSMutableDictionary dictionaryWithContentsOfFile:pathData] ;
    
    if (dicData != nil && idUsr > 0)
    {
        [dicData setObject:[[NSNumber alloc] initWithInt:idUsr] forKey:@"idUser"];
        BOOL ret = [dicData writeToFile:pathData atomically:YES];
        
        if (ret)
        {
            NSLog(@"Write iduser :%i successful ", idUsr);
        }
        else
        {
            NSLog(@"Write iduser :%i fail ", idUsr);
        }
      
    }
    else
    {
        NSLog(@"Write iduser :%i fail ", idUsr);
    }
    
}

- (void) saveLevel:(int32_t)level andRuby:(int32_t)ruby
{
    
    NSString *pathData = [[NSBundle mainBundle]
                          pathForResource: @"Data"
                          ofType:@"plist"] ;
    
    NSMutableDictionary *dicData = [NSMutableDictionary dictionaryWithContentsOfFile:pathData] ;
    
    if (dicData != nil)
    {
        [dicData setObject:[NSNumber numberWithInt:level] forKey:@"level"];
        [dicData setObject:[NSNumber numberWithInt:ruby] forKey:@"ruby"];
        [dicData writeToFile:pathData atomically:YES];
        
        NSLog(@"Save level: %i and ruby : %i",level,ruby);
    }
    else
    {
        NSLog(@"Save level and ruby fail!!");
    }
}

- (NSString*) createEnSuggestResult :(NSString*) enResult
{
    NSMutableString *str1 = [[NSMutableString alloc]initWithString:enResult];
    
    for (int i= 0 ; i < NUM_RANDOM_BUTTON - [enResult length] ; i++)
    {
        int k = arc4random() % [ALPHABETA length];
        char ch = [ALPHABETA characterAtIndex:k];
        [str1 appendFormat:@"%c", ch];
    }
    
    
    NSMutableString *str2 = [[NSMutableString alloc] init];
    while ([str1 length] > 0)
    {
        int i = arc4random() % [str1 length];
        NSRange range = NSMakeRange(i,1);
        NSString *sub = [str1 substringWithRange:range];
        [str2 appendString:sub];
        [str1 replaceOccurrencesOfString:sub withString:@"" options:nil range:range];
    }
    
    return str2;
}

-(void) saveImage:(NSData*)image andEnResult:(NSString*)enResult andEnSuggestResult:(NSString*)enSuggestResult andVnResult:(NSString*)vnResult
{
    NSString *pathData = [[NSBundle mainBundle]
                          pathForResource: @"Data"
                          ofType:@"plist"] ;
    
    NSMutableDictionary *dicData = [NSMutableDictionary dictionaryWithContentsOfFile:pathData] ;
    
    
    
    if (dicData != nil)
    {
        [dicData setObject:image forKey:@"image"];
        [dicData setObject:enResult forKey:@"enResult"];
        [dicData setObject:enSuggestResult forKey:@"enSuggestResult"];
        [dicData setObject:vnResult forKey:@"vnResult"];
        
        [dicData writeToFile:pathData atomically:YES];
        
        NSLog(@"Save image and en result: %@ and suggest result : %@ and vietnam result : %@",enResult,mEnSuggestResult,vnResult);
    }
    else
    {
        NSLog(@"Save image fail!!");
    }

}

- (BOOL) serviceConnectedServer
{
    return [mService isConnected];
}
- (void) mainThread
{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        //parsing methods here
        
        isRunning = TRUE;
        while (isRunning)
        {
            NSData *msg = [mService popMsg];
            if (msg == nil)
            {
                [NSThread sleepForTimeInterval:.05];
            }
            else
            {
                [self processMsg:msg];
            }
            
        }
        
        dispatch_async(dispatch_get_main_queue(), ^{
            //[self taskLogin];
            
        });
        
    });

}


- (void) processMsg: (NSData*) pMsg
{
    if(pMsg == nil || [pMsg length] <= 0)
        return;
    
    NSInteger offset = 0;
    
    int32_t MsgType = -1;
    [[NSData dataWithBytesNoCopy:(char*)[pMsg bytes] + offset length:sizeof(int32_t) freeWhenDone:NO] getBytes:&MsgType length:sizeof(MsgType)];
    offset = offset + sizeof(int32_t);
    
    MsgType = ntohl(MsgType);
    
    switch (MsgType)
    {
        case MSG_REQ:
            [self processResquestMsg:[NSData dataWithBytesNoCopy:(char*)[pMsg bytes] + offset length: ([pMsg length] - sizeof(int32_t)) freeWhenDone:NO]];
            break;
            
        case MSG_RES:
            [self processResponseMsg:[NSData dataWithBytesNoCopy:(char*)[pMsg bytes] + offset length: ([pMsg length] - sizeof(int32_t)) freeWhenDone:NO]];
            break;
        default:
            break;
    }
    
}


- (void) processResponseMsg: (NSData*)pMsg
{
    if(pMsg == nil || [pMsg length] <= 0)
        return;
    
    NSInteger offset = 0;
    int32_t MsgResType = -1;
    [[NSData dataWithBytesNoCopy:(char*)[pMsg bytes] + offset length:sizeof(int32_t) freeWhenDone:NO] getBytes:&MsgResType length:sizeof(MsgResType)];
    offset = offset + sizeof(int32_t);
    
    MsgResType = ntohl(MsgResType);
    
    switch (MsgResType)
    {
        case MSG_RES_CONNECT_OK:
        {
            [self pushUIMsg:UI_CONNECT_OK];
            break;
        }
        case MSG_RES_CONNECT_FAIL:
        {
            [self pushUIMsg:UI_CONNECT_FAIL];
            break;
        }
        case MSG_RES_DISCONNECT_OK:
        {
            [self pushUIMsg:UI_DISCONNECT_OK];
            break;
        }
        case MSG_RES_CREATE_USER_OK:
        {
            int32_t idUser = -1 ;
            [[NSData dataWithBytesNoCopy:(char*)[pMsg bytes] + offset length:sizeof(int32_t) freeWhenDone:NO] getBytes:&idUser length:sizeof(idUser)];
            mUserID = ntohl(idUser);
            
            if (idUser > 0)
            {
                [self saveIdUser:mUserID];
            }
            
            [self pushUIMsg:UI_CREATE_USER_OK];
            break;
        }
        case MSG_RES_CREATE_USER_FAIL:
        {
            [self pushUIMsg:UI_CREATE_USER_FAIL];
            break;
        }
            
        case MSG_RES_NEXT_LEVEL_OK:
        {
            //read enresult
            int32_t lengEn = -1 ;
            [[NSData dataWithBytesNoCopy:(char*)[pMsg bytes] + offset length:sizeof(int32_t) freeWhenDone:NO] getBytes:&lengEn length:sizeof(lengEn)];
            lengEn = ntohl(lengEn);
            offset = offset + sizeof(int32_t);
            mEnResult = [[NSString stringWithUTF8String:[[NSData dataWithBytesNoCopy:(char*)[pMsg bytes] + offset length:lengEn freeWhenDone:NO] bytes]] uppercaseString];
            mEnSuggestResult = [self createEnSuggestResult:mEnResult];
            offset = offset + lengEn;
            
            
            //read vnresult
            int32_t lengVn = -1 ;
            [[NSData dataWithBytesNoCopy:(char*)[pMsg bytes] + offset length:sizeof(int32_t) freeWhenDone:NO] getBytes:&lengVn length:sizeof(lengVn)];
            lengVn = ntohl(lengVn);
            offset = offset + sizeof(int32_t);
            mVnResult = [NSString stringWithUTF8String:[[NSData dataWithBytesNoCopy:(char*)[pMsg bytes] + offset length:lengVn freeWhenDone:NO] bytes]];
            offset = offset + lengVn;
            
            //read image
            int32_t lengImage = -1 ;
            [[NSData dataWithBytesNoCopy:(char*)[pMsg bytes] + offset length:sizeof(int32_t) freeWhenDone:NO] getBytes:&lengImage length:sizeof(lengImage)];
            lengImage = ntohl(lengImage);
            offset = offset + sizeof(int32_t);
            
            mImage = [NSData dataWithBytesNoCopy:(char*)[pMsg bytes] + offset length:lengImage freeWhenDone:NO];
            
            //save
            [self saveImage:mImage andEnResult:mEnResult andEnSuggestResult: mEnSuggestResult andVnResult:mVnResult];
            
            //put ui message
            [self pushUIMsg:UI_NEXT_LEVEL_OK];
            
            
            break;
        }
        case MSG_RES_NEXT_LEVEL_FAIL:
        {
            [self pushUIMsg:UI_NEXT_LEVEL_FAIL];
            break;
        }
        case MSG_RES_UPDATE_USERNAME_OK:
        {
            [self pushUIMsg:UI_UPDATE_USERNAME_OK];
            break;
        }
        case MSG_RES_UPDATE_USERNAME_FAIL:
        {
            [self pushUIMsg:UI_UPDATE_USERNAME_FAIL];
            break;
        }
        case MSG_RES_UPDATE_FACEBOOK_OK:
        {
            [self pushUIMsg:UI_UPDATE_FACEBOOK_OK];
            break;
        }
        case MSG_RES_UPDATE_FACEBOOK_FAIL:
        {
            [self pushUIMsg:UI_UPDATE_FACEBOOK_FAIL];
            break;
        }
       
        default:
            break;
    }

    
}


- (void) processResquestMsg: (NSData*)pMsg
{
    
}



- (void) connectServer
{
    [mService connect];
}

- (void) createUser
{
    
    int32_t MsgType = MSG_REQ;
    int32_t MsgReqType = MSG_REQ_CREATE_USER;
    int32_t lengMsg = sizeof(MsgType) + sizeof(MsgReqType);
    
    MsgType = htonl(MsgType);
    MsgReqType = htonl(MsgReqType);
    lengMsg = htonl(lengMsg);
    
    NSMutableData *dataLeng = [NSData dataWithBytesNoCopy:&lengMsg length:sizeof(lengMsg) freeWhenDone:NO];
    NSMutableData *data1 = [NSData dataWithBytesNoCopy:&MsgType length:sizeof(MsgType) freeWhenDone:NO];
    NSMutableData *data2 = [NSData dataWithBytesNoCopy:&MsgReqType length:sizeof(MsgReqType) freeWhenDone:NO];
    NSMutableData *data = [[NSMutableData alloc] init];
    [data appendData:dataLeng];
    [data appendData:data1];
    [data appendData:data2];
    
    [mServiceLock lock];
    [mService writeWithData:data tag:TAG_MSG_REQ_CREATE_USER];
    [mServiceLock unlock];
    
}


- (void) nextLevel
{
    
    int32_t MsgType = MSG_REQ;
    int32_t MsgReqType = MSG_REQ_NEXT_LEVEL;
    int32_t idUser  = mUserID ;
    int32_t lengMsg = sizeof(MsgType) + sizeof(MsgReqType) + sizeof(idUser);
    
    MsgType = htonl(MsgType);
    MsgReqType = htonl(MsgReqType);
    idUser = htonl(idUser);
    lengMsg = htonl(lengMsg);
    
    NSMutableData *dataLeng = [NSData dataWithBytesNoCopy:&lengMsg length:sizeof(lengMsg) freeWhenDone:NO];
    NSMutableData *data1 = [NSData dataWithBytesNoCopy:&MsgType length:sizeof(MsgType) freeWhenDone:NO];
    NSMutableData *data2 = [NSData dataWithBytesNoCopy:&MsgReqType length:sizeof(MsgReqType) freeWhenDone:NO];
    NSMutableData *data3 = [NSData dataWithBytesNoCopy:&idUser length:sizeof(idUser) freeWhenDone:NO];
    
    NSMutableData *data = [[NSMutableData alloc] init];
    [data appendData:dataLeng];
    [data appendData:data1];
    [data appendData:data2];
    [data appendData:data3];    
    
    
    [mServiceLock lock];
    [mService writeWithData:data tag:TAG_MSG_REQ_NEXT_LEVEL];
    [mServiceLock unlock];    
    
}


- (void) updateFacebook
{
    [mServiceLock lock];
}


- (void) updateUsername
{
    [mServiceLock lock];
}


- (void) pushUIMsg : (int32_t)uiMsg
{
    [mListUIMsgLock lock];
    [mListUIMsg addObject:[NSNumber numberWithInt:uiMsg]];
    [mListUIMsgLock unlock];
    
}

- (int32_t) popUIMsg
{
    [mListUIMsgLock lock] ;
    
    if ([mListUIMsg count] > 0)
    {
        int32_t uiMsg = (int32_t)[[mListUIMsg objectAtIndex:0] integerValue];
        [mListUIMsg removeObjectAtIndex:0];
        
        [mListUIMsgLock unlock] ;
        return uiMsg;
    }
    
    [mListUIMsgLock unlock] ;
    return -1;
}

@end
